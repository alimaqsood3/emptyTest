const puppeteer = require("puppeteer");


 async function start(){
    const browser = await puppeteer.launch()
    const page = await browser.newPage()
    await page.goto('http://google.com')
    await page.screenshot({path: "aw.png"})
    await browser.close
}
start();


