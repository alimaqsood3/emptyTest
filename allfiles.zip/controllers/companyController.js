const Company = require("../models/Company");
const util = require('util')
const fs = require('fs')
const unlinkFile = util.promisify(fs.unlink)
// s3
const { uploadFileToS3ByImagePath, uploadAudioToS3 } = require("../helpers/s3");

const {
  company_put_schema,
  company_address_put_schema
} = require("../validations/company.validation");
module.exports.company_get = async (req, res, next) => {
  try {
    let company = await Company.findOne({ user: req.user._id });
    console.log(company)
    return res.status(200).json({ data: company });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.company_put = async (req, res, next) => {
  try {
    const { id } = req.params;
    await company_put_schema.validateAsync(req.body);
    await Company.findOneAndUpdate(
      {
        $and: [
          {
            _id: id
          },
          {
            user: req.user._id
          }
        ]
      },
      { ...req.body },
      { upsert: true }
    );
    const company = await Company.findById(id)
    return res.status(200).json({ msg: "Company data updated Successfully", company });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.company_address_put = async (req, res, next) => {
  try {
    const { id } = req.params;
    await company_address_put_schema.validateAsync(req.body);
    await Company.findOneAndUpdate(
      {
        $and: [
          {
            _id: id
          },
          {
            user: req.user._id
          }
        ]
      },
      { ...req.body },
      { upsert: true }
    );
    const company = await Company.findById(id)
    return res
      .status(200)
      .json({ msg: "Company Address updated Successfully", company });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.company_missedcall_put = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { missedCall } = req.body;
    await Company.findOneAndUpdate(
      {
        $and: [
          {
            _id: id
          },
          {
            user: req.user._id
          }
        ]
      },
      { missedCall },
      { upsert: true }
    );
    const company = await Company.findById(id)
    return res
      .status(200)
      .json({ company, msg: "Company Missed Call Settings updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.company_generalSetting_put = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { duplicateContacts, duplicateOpportunity, disableContactTimezone } =
      req.body;
    await Company.findOneAndUpdate(
      {
        $and: [
          {
            _id: id
          },
          {
            user: req.user._id
          }
        ]
      },
      {
        duplicateContacts,
        duplicateOpportunity,
        disableContactTimezone
      },
      { upsert: true }
    );
    const company = await Company.findById(id)
    return res
      .status(200)
      .json({ company, msg: "Company General Settings updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.company_profile_picture_patch = async (req, res, next) => {
  const { company_id } = req.params;
  const uri = req.body.logo.toString().split(";base64,")
  const imageExtension = uri[0].toString().split('/')[1]
  const filePath = `./uploads/${company_id}-${Date.now()}.${imageExtension}`;
  const buffer = await Buffer.from(uri[1], "base64");
  await fs.writeFileSync(filePath, buffer);
  const fileUrl = await uploadFileToS3ByImagePath(filePath, company_id);
  const logoFile = fileUrl.Location;
  await Company.findOneAndUpdate(
    {
      $and: [
        {
          _id: company_id
        },
        {
          user: req.user._id
        }
      ]
    },
    { companyLogo: logoFile },
    { upsert: true }
  );
  await unlinkFile(filePath);
  const company = await Company.findById(company_id)
  return res
    .status(200)
    .json({ data: company, msg: "Company Logo updated Successfully" });
}

module.exports.company_voicemail_patch = async (req, res, next) => {
  const { company_id } = req.params;
  const file = req.file.buffer;
  const { voiceTimeout } = req.body;
  // checking if audio is selected or not
  if (req.file && req.file !== undefined) {
    if (req.file.length === 0) {
      return res.send({ msg: 'You must select at least 1 audio file.' });
    }
    else if (req.file.length > 1) {
      return res.send({ msg: "Only 1 audio is allowed" });
    }
  } else {
    return res.send({ msg: 'You must select at least 1 audio file.' });
  }
  const result = await uploadAudioToS3(company_id, file)
  await Company.findOneAndUpdate(
    {
      $and: [
        {
          _id: company_id
        },
        {
          user: req.user._id
        }
      ]
    },
    { voiceAudio: result.Location, voiceTimeout },
    { upsert: true }
  );
  const company = await Company.findById(company_id)
  return res
    .status(200)
    .json({ data: company, msg: "Company Audio Voicemail & Voice Timeout updated Successfully" });
}



module.exports.company_stages_put = async (req, res, next) => {
  try {
    const { id } = req.params;

    const company = await Company.findOneAndUpdate(
      {
        $and: [
          {
            _id: id
          },
          {
            user: req.user._id
          }
        ]
      },
      {
        ...req.body
      },
      { upsert: true }
    );

    return res
      .status(200)
      .json({ data: company, msg: "Company Stages updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};
