const SmtpService = require("../models/SmtpService");
const {
  smtpService_post_schema,
  smtpService_put_schema,
} = require("../validations/smtpService.validation");
const { getEmployerId } = require("../helpers/utils");
module.exports.smtpService_get = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);

    let smtpServices = await SmtpService.find({ user: userId });

    return res.status(200).json({ data: smtpServices });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.smtpService_post = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);

    await smtpService_post_schema.validateAsync(req.body);

    await SmtpService.create({ ...req.body, user: userId });

    return res.status(200).json({ msg: "smtpService Created Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.smtpService_put = async (req, res, next) => {
  try {
    await smtpService_put_schema.validateAsync(req.body);

    const smtpService = await SmtpService.findOneAndUpdate(
      { _id: req.params.id },
      req.body,
      { new: true }
    );

    return res
      .status(200)
      .json({ data: smtpService, msg: "smtpService updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.smtpService_delete = async (req, res, next) => {
  let smtpServices = await SmtpService.deleteOne({ _id: req.params.id });

  return res.status(200).json({ data: smtpServices });
};
