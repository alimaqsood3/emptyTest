const PhoneNumber = require("../models/PhoneNumber");
const {
  phoneNumber_post_schema,
  phoneNumber_put_schema,
} = require("../validations/phoneNumber.validation");
const dotenv = require("dotenv")
// dotenv config
dotenv.config();

const client = require("twilio")(process.env.TIWILIO_ACCOUNT_SID, process.env.TIWILIO_AUTH_TOKEN);
const { getEmployerId, getCompanyId } = require("../helpers/utils");


module.exports.phoneNumber_get = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);
    let phoneNumbers = await PhoneNumber.find({ user: userId });
    return res.status(200).json({ data: phoneNumbers });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.phoneNumber_post = async (req, res, next) => {
  try {
    await phoneNumber_post_schema.validateAsync(req.body);
    const userId = getEmployerId(req.user);
    const company = await getCompanyId(req.user);
    let phoneNumber = await PhoneNumber.findOne({
      $and: [{
        company
      },
      {
        user: userId
      },
      {
        phoneNumber: req.body.phoneNumber
      }]
    })
    if (phoneNumber) {
      return res
        .status(400)
        .json({ msg: "Phone Number Already Exists", phoneNumber });

    }
    let response = await client.incomingPhoneNumbers
      .create({ phoneNumber: req.body.phoneNumber })
      .then((incoming_phone_number) => incoming_phone_number);
    phoneNumber = new PhoneNumber({
      ...req.body,
      numberSid: response.sid,
      user: userId,
      company
    });
    await phoneNumber.save();
    return res.status(200).json({ msg: "Phone Number Created Successfully", phoneNumber });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.twillio_number_get = async (req, res, next) => {
  try {
    const { countryCode, areaCode } = req.body;
    let response = await client
      .availablePhoneNumbers(countryCode)
      .local.list({ areaCode: areaCode, limit: 20 })
      .then((mobile) => mobile);
    return res.status(200).json({ data: response });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.phoneNumber_put = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);
    await phoneNumber_put_schema.validateAsync(req.body);
    await PhoneNumber.findOneAndUpdate(
      {
        $and: [{
          _id: req.params.id
        },
        {
          user: userId
        }]
      },
      req.body,
      {
        new: true,
      }
    );
    const phoneNumber = await PhoneNumber.findById(req.params.id)
    return res
      .status(200)
      .json({ data: phoneNumber, msg: "Phone Number updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.phoneNumber_delete = async (req, res, next) => {
  await PhoneNumber.deleteOne({ _id: req.params.id });
  const userId = getEmployerId(req.user);
  let phoneNumbers = await PhoneNumber.find({ user: userId });
  return res.status(200).json({ data: phoneNumbers });
};