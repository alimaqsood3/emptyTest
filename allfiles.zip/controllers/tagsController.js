const Tag = require("../models/Tag");
const {
  tag_post_schema,
  tag_put_schema,
} = require("../validations/tag.validation");
const { getCompanyId } = require("../helpers/utils");
module.exports.tag_get = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    let tags = await Tag.find({ company: companyId });
    return res.status(200).json({ data: tags });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.tag_post = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    await tag_post_schema.validateAsync(req.body);
    let flagTag = await Tag.findOne({
      $and: [{
        "name": req.body.name
      }, {
        company: companyId
      }]
    })
    if (flagTag) {
      return res.status(400).json({ msg: "Tag Already Exists with given name", flagTag });
    }
    const tag = new Tag({ ...req.body, company: companyId })
    await tag.save();
    return res.status(200).json({ msg: "tag Created Successfully", tag });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.tag_put = async (req, res, next) => {
  try {
    await tag_put_schema.validateAsync(req.body);
    await Tag.findOneAndUpdate({ _id: req.params.id }, req.body, {
      new: true,
    });
    const tag = await Tag.findById(req.params.id);
    return res.status(200).json({ data: tag, msg: "Tag updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.tag_delete = async (req, res, next) => {
  await Tag.deleteOne({ _id: req.params.id });
  const companyId = await getCompanyId(req.user);
  const tags = await Tag.find({ company: companyId })
  return res.status(200).json({ data: tags });
};
