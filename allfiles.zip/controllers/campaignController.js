const Campaign = require("../models/Campaign");
const {
  campaign_post_schema,
  campaign_put_schema,
  campaign_patch_schema,
} = require("../validations/campaign.validation");

const { getEmployerId } = require("../helpers/utils");

module.exports.campaign_get = async (req, res, next) => {
  try {
    let campaigns = await Campaign.find({ user: req.user._id });
    return res.status(200).json({ data: campaigns });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.campaign_post = async (req, res, next) => {
  try {
    await campaign_post_schema.validateAsync(req.body);
    const campaign = await new Campaign({
      user: req.user._id,
      name: req.body.name
    })
    await campaign.save();
    return res.status(200).json({ msg: "Campaign Created Successfully", campaign });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.campaign_patch = async (req, res, next) => {
  try {
    await campaign_patch_schema.validateAsync(req.body);
    const {
      name,
      status,
      configuration
    } = req.body;
    const campaignBuildObjects = {};
    if (name) campaignBuildObjects.name = name;
    if (status) campaignBuildObjects.status = status;
    if (configuration) campaignBuildObjects.configuration = configuration;
    let campaign = await Campaign.findOneAndUpdate(
      { _id: req.params.id },
      req.body
    );
    campaign = await Campaign.findById(req.params.id)
    return res
      .status(200)
      .json({ data: campaign, msg: "Campaign updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.campaign_delete = async (req, res, next) => {
  await Campaign.deleteOne({
    $and: [{ _id: req.params.id },
    { user: req.user._id }]
  });
  let campaigns = await Campaign.find({ user: req.user._id });
  return res.status(200).json({ data: campaigns });
};
