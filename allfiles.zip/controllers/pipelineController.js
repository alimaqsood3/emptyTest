const Pipeline = require("../models/Pipeline");
const Stage = require("../models/Stage");
const mongoose = require("mongoose");

const { getEmployerId } = require("../helpers/utils");

module.exports.pipeline_post = async (req, res, next) => {
  console.log(req.body);
  const userId = getEmployerId(req.user);
  const { stages } = req.body;
  let stagesIds = [];
  for (let i = 0; i < stages.length; i++) {
    let newStage = new Stage();
    newStage.name = stages[i].name;
    newStage.isVisibleInFunnel = stages[i].isVisibleInFunnel;
    newStage.isVisibleInPie = stages[i].isVisibleInPie;

    await newStage.save();
    stagesIds.push(newStage._id);
  }

  const pipeline = await Pipeline.create({
    ...req.body,
    assignTo: req.body.assignTo.map((item) => mongoose.Types.ObjectId(item)),
    user: userId,
    stages: stagesIds,
  });
  res.status(200).json({ data: pipeline });
};

module.exports.pipeline_get = async (req, res, next) => {
  const userId = getEmployerId(req.user);

  const pipeline = await Pipeline.find({ user: req.user._id })
    .populate("stages")
    .populate("opportunities")
    .populate("assignTo");
  res.status(200).json({ data: pipeline });
};

module.exports.pipeline_put = async (req, res, next) => {
  const { assignTo, name } = req.body;

  const { stages } = req.body;
  let stagesIds = [];
  for (let i = 0; i < stages.length; i++) {
    if (stages[i]._id) {
      await Stage.findByIdAndUpdate(stages[i]._id, {
        name: stages[i].name,
        isVisibleInFunnel: stages[i].isVisibleInFunnel,
        isVisibleInPie: stages[i].isVisibleInPie,
      });
      stagesIds.push(stages[i]._id);
    } else {
      let newStage = new Stage();
      newStage.name = stages[i].name;
      newStage.isVisibleInFunnel = stages[i].isVisibleInFunnel;
      newStage.isVisibleInPie = stages[i].isVisibleInPie;

      await newStage.save();
      stagesIds.push(newStage._id);
    }
  }

  const pipeline = await Pipeline.findByIdAndUpdate(req.params.id, {
    ...req.body,
    assignTo: req.body.assignTo.map((item) => mongoose.Types.ObjectId(item)),
    stages: stagesIds,
  });
  res.status(200).json({ data: pipeline });
};

module.exports.pipeline_delete = async (req, res, next) => {
  const pipeline = await Pipeline.findByIdAndDelete(req.params.id);
  res.status(200).json({ data: pipeline });
};
