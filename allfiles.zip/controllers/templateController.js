const Template = require("../models/Template");
const SmtpService = require("../models/SmtpService");
const {
  template_post_schema,
  template_put_schema,
} = require("../validations/template.validation");
const { getEmployerId, getCompanyId } = require("../helpers/utils");
const SendMail = require("../helpers/mailer");

module.exports.template_get = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    let templates = await Template.find({ company: companyId });
    return res.status(200).json({ data: templates });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.template_post = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    await template_post_schema.validateAsync(req.body);
    const template = new Template({ ...req.body, company: companyId })
    await template.save();
    return res.status(200).json({ msg: "template Created Successfully", template });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.template_put = async (req, res, next) => {
  try {
    await template_put_schema.validateAsync(req.body);
    await Template.findOneAndUpdate(
      { _id: req.params.id },
      req.body,
      { new: true }
    );
    const template = await Template.findById(req.params.id)
    return res
      .status(200)
      .json({ msg: "template updated Successfully", template });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.template_delete = async (req, res, next) => {
  await Template.deleteOne({ _id: req.params.id });
  const companyId = await getCompanyId(req.user);
  let templates = await Template.find({ company: companyId });
  return res.status(200).json({ data: templates,msg:`Template with id # ${req.params.id} deleted successfully` });
};

module.exports.template_test = async (req, res, next) => {
  const { from, to, body, subject } = req.body;
  const SmtpProvider = await SmtpService.findOne({ user: req.user._id });
  if (!SmtpProvider) {
    return res.status(400).json({ msg: "No SMTP Service found" });
  }
  SendMail(from, to, { body, subject }, SmtpProvider);
  res.status(200).json({ msg: "Email sent successfully" });
};
