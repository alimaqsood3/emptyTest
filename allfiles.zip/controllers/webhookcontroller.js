const Conversation = require('../models/Conversation');
const User = require("../models/User");

module.exports.incoming = async (req, res, next) => {

    const _id = await getUserId(req.body.rcpt_to);
    if (!_id) {
        return res.status(400).json({ message: "User does not exists in our system" });
    }
    let conversation;
    try {
        conversation = await Conversation.findOne(
            {
                $and: [
                    { user: _id },
                    { "emailConversations.email": req.body.mail_from }
                ]
            }
        )
        if (conversation) {
            const newConvo = {
                type: "RECEIVED",
                data: {
                    name: req.body.from.toString().split('<')[0],
                    subject: req.body.subject,
                    body: req.body.html_body
                }
            }
            for (let i = 0; i < conversation.emailConversations.length; i++) {
                if (conversation.emailConversations[i].email.toString().includes(req.body.mail_from)) {
                    conversation.emailConversations[i].convo.push(newConvo)
                    conversation.emailConversations[i].read.isRead = false;
                    break;
                }
            }
            await conversation.save();
        } else {
            conversation = await Conversation.findOne(
                {
                    $and: [
                        { user: _id },
                        { "emailConversations.email": req.body.mail_from }
                    ]
                }
            )
            if (!conversation) {
                conversation = await new Conversation({
                    user: _id,
                    emailConversations: [{
                        email: req.body.mail_from,
                        convo: [
                            {
                                type: "RECEIVED",
                                data: {
                                    name: req.body.from.toString().split('<')[0],
                                    subject: req.body.subject,
                                    body: req.body.html_body
                                }
                            }
                        ],
                        read: {
                            isRead: false
                        }
                    }],
                })
                await conversation.save();
            } else {
                conversation.emailConversations.push({
                    email: req.body.mail_from,
                    convo: [
                        {
                            type: "RECEIVED",
                            data: {
                                name: req.body.from.toString().split('<')[0],
                                subject: req.body.subject,
                                body: req.body.html_body
                            }
                        }
                    ],
                    read: {
                        isRead: false
                    }
                })
                await conversation.save();
            }
        }
    } catch (error) {
        console.error(error)
    }
    res.status(200).json({ success: true, message: "Email sent successfully" });
}

module.exports.outgoing = async (req, res, next) => {
    // res.status(200).json({ success: true, message: "Email sent successfully" });

}

// function to get user id
async function getUserId(email) {
    let user = await User.findOne({ email });
    if (!user) {
        return null;
    } else {
        return user._id;
    }
}
