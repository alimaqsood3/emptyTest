const Opportunity = require("../models/Oppurtunity");
const Pipeline = require("../models/Pipeline");
const Contact = require("../models/Contact");
const mongoose = require("mongoose");
const {
  opportunity_post_add_new_placement_opportunity_schema,
  opportunity_put_schema,
  opportunity_post_add_candidate_to_existing_placement_schema
} = require("../validations/opportunity.validation");

const { getEmployerId } = require("../helpers/utils");
module.exports.opportunity_get = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);
    let opportunitys = await Opportunity.find({ user: userId }).populate(
      "addCandidateToExistingPlacement.opportunityInfo.pipeline addCandidateToExistingPlacement.opportunityInfo.owner addCandidateToExistingPlacement.contactInfo addCandidateToExistingPlacement.opportunityInfo.stage"
    );
    return res.status(200).json({ data: opportunitys });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.opportunity_post = async (req, res, next) => {
  try {
    
    const userId = getEmployerId(req.user);
    if (req.body.addCandidateToExistingPlacement) {
      await opportunity_post_add_candidate_to_existing_placement_schema.validateAsync(req.body);
      const {
        contactName,
        contactEmail,
        contactPhone,
        tags,
        companyName
      } = req.body.addCandidateToExistingPlacement.contactInfo;
      const contact = await Contact.findOne({
        email: contactEmail
      })
      if (contact) {
        return res.status(500).json({ error: `Contact With Email # ${contactEmail} Already Exists` });
      }
      let newContact = await Contact.create({
        firstName: contactName,
        lastName: "",
        email: contactEmail,
        phone: contactPhone,
        tags,
        companyName,
        contactType: null,
        source: null,
        user: userId,
      });
      req.body.addCandidateToExistingPlacement.contactInfo = newContact._id;
      await newContact.save();
      let newOPP = await Opportunity.create({
        ...req.body,
        user: userId,
      });
      await newOPP.save();
      await Pipeline.findByIdAndUpdate(req.body.addCandidateToExistingPlacement.opportunityInfo.pipeline, {
        $push: { opportunities: newOPP._id },
      });
      let oppr = await Opportunity.findOne({ _id: newOPP._id }).populate(
        "addCandidateToExistingPlacement.opportunityInfo.pipeline addCandidateToExistingPlacement.opportunityInfo.owner addCandidateToExistingPlacement.contactInfo addCandidateToExistingPlacement.opportunityInfo.stage"
      );
      return res
        .status(200)
        .json({ msg: "opportunity (Add Candidate To Existing Opportunity) Created Successfully", data: oppr });
    }
    else if (req.body) {
     opportunity_post_add_new_placement_opportunity_schema.validateAsync(req.body);
      let newOPP = await Opportunity.create({
        ...req.body,
        user: userId,
      });
      await newOPP.save();
      return res
        .status(200)
        .json({ msg: "opportunity (Add New Placement) Created Successfully", data: newOPP });
    }
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.opportunity_put = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);
    if (req.body.addCandidateToExistingPlacement) {
      await opportunity_post_add_candidate_to_existing_placement_schema.validateAsync(req.body);
      const {
        contactName,
        contactEmail,
        contactPhone,
        tags,
        companyName
      } = req.body.addCandidateToExistingPlacement.contactInfo;
      await Contact.findOneAndUpdate({
        email: contactEmail
      }, {
        firstName: contactName,
        lastName: "",
        email: contactEmail,
        phone: contactPhone,
        tags,
        companyName,
        contactType: null,
        source: null,
        user: userId,
      }
      )
      await Opportunity.findOneAndUpdate({ _id: req.params.id }, {
        opportunityInfo: req.body.addCandidateToExistingPlacement.opportunityInfo
      })
      await Pipeline.findByIdAndUpdate(req.body.addCandidateToExistingPlacement.opportunityInfo.pipeline, {
        $push: { opportunities: newOPP._id },
      });
      let oppr = await Opportunity.findOne({ _id: req.params.id }).populate(
        "addCandidateToExistingPlacement.opportunityInfo.pipeline addCandidateToExistingPlacement.opportunityInfo.owner addCandidateToExistingPlacement.contactInfo addCandidateToExistingPlacement.opportunityInfo.stage"
      );
      return res
        .status(200)
        .json({ msg: "opportunity (Add Candidate To Existing Opportunity) Updated", data: oppr });
    }
    else if (req.body.addNewPlacementOpportunity) {
      await opportunity_post_add_new_placement_opportunity_schema.validateAsync(req.body);
      await Opportunity.findOneAndUpdate({
        _id: req.params.id
      }, {
        ...req.body,
        user: userId,
      });
      let oppr = await Opportunity.findOne({ _id: req.params.id }).populate(
        "addCandidateToExistingPlacement.opportunityInfo.pipeline addCandidateToExistingPlacement.opportunityInfo.owner addCandidateToExistingPlacement.contactInfo addCandidateToExistingPlacement.opportunityInfo.stage"
      );
      return res
        .status(200)
        .json({ msg: "opportunity (Add New Placement) Updated Successfully", data: oppr });
    }
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.opportunity_delete = async (req, res, next) => {
  let opportunitys = await Opportunity.deleteOne({ _id: req.params.id });
  return res.status(200).json({ data: opportunitys });
};
