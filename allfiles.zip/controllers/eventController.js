const Event = require('../models/Event')
const express = require("express");
const SendMail = require('../helpers/mailer');
const SmtpService = require('../models/SmtpService');
//Conversation with SMS Chunk------------------------------------------------------------------
const accountSid = 'AC7fbdfbe89073e71671ae410a595f3831';
const authToken = '0b8fcc56dc9a9cc320be807e9f3a0533 ';
const client = require('twilio')(accountSid, authToken);
app = express();
const {
  event_post_schema
} = require("../validations/event.validation");

module.exports.event_post = async (req, res, next) => {
  try {
    await event_post_schema.validateAsync(req.body);
    if (req.body.type.toString().includes("SMS") && !req.body.smsEvent) {
      return res.status(401).json({ error: "Something went wrong..." });
    } else if (req.body.type.toString().includes("EMAIL") && !req.body.emailEvent) {
      return res.status(401).json({ error: "Something went wrong..." });
    } else if (req.body.emailEvent && req.body.smsEvent) {
      return res.status(401).json({ error: "Something went wrong..." });
    }
    const event = await new Event(req.body);
    await event.save();
    if (req.body.type.toString().includes("EMAIL")) {
      const template = {
        subject: req.body.emailEvent.subjectLine,
        text: req.body.emailEvent.body
      }
      const SmtpProvider = await SmtpService.findOne({ user: req.user._id });
      if (!SmtpProvider)
        return res.status(400).json({ msg: 'Please add SMTP service first' });
      SendMail("zain80775@gmail.com", "zain80776@gmail.com", template, SmtpProvider);
    }
    if (req.body.type.toString().includes("SMS")) {
      client.messages
        .create({ body: req.body.smsEvent.text, from: req.body.smsEvent.from, to: req.body.smsEvent.to })
        .then(message => {
          console.log(message.sid)
        });
    }
    return res.status(200).json(event);
  } catch (err) {
    console.log(err);
    return res.status(500).json(err);
  }
}

module.exports.event_patch = async (req, res, next) => {
  try {
    await event_post_schema.validateAsync(req.body);
    if (req.body.type.toString().includes("SMS") && !req.body.smsEvent) {
      return res.status(401).json({ error: "Something went wrong..." });
    } else if (req.body.type.toString().includes("EMAIL") && !req.body.emailEvent) {
      return res.status(401).json({ error: "Something went wrong..." });
    } else if (req.body.emailEvent && req.body.smsEvent) {
      return res.status(401).json({ error: "Something went wrong..." });
    }
    let event = await Event.findById(req.params.eventID)
    if (event.type.toString().includes("EMAIL") && req.body.type.toString().includes("SMS")) {
      event.emailEvent = {};
      await event.save();
    }
    else if (event.type.toString().includes("SMS") && req.body.type.toString().includes("EMAIL")) {
      event.smsEvent = {};
      await event.save();
    }
    event = await Event.findOneAndUpdate(
      { _id: req.params.eventID },
      req.body
    );
    event = await Event.findById(req.params.eventID)
    return res
      .status(200)
      .json({ data: event, msg: "Event updated Successfully" });
  } catch (err) {
    console.log(err);
    return res.status(500).json(err);
  }
}


module.exports.event_get_for_particular_campaign = async (req, res, next) => {
  try {
    let event = await Event.find({ campaign: req.params.campaignID });
    return res.status(200).json(event);
  } catch (err) {
    console.log(err);
    return res.status(500).json(err);
  }
};

module.exports.event_get = async (req, res, next) => {
  try {
    let event = await Event.findById(req.params.eventID);
    return res.status(200).json(event);
  } catch (err) {
    console.log(err);
    return res.status(500).json(err);
  }
};

module.exports.event_delete = async (req, res, next) => {
  try {
    await Event.findByIdAndDelete(req.params.eventID);
    return res.status(200).json({ msg: `Event with id # ${req.params.eventID} is deleted` });
  } catch (err) {
    console.log(err);
    return res.status(500).json(err);
  }
};


