const TeamManagement = require('../models/TeamManagement');
const User = require('../models/User');
const SmtpService = require('../models/SmtpService');
const SendMail = require('../helpers/mailer');
var dotenv = require('dotenv');
const { generatePasswordHash } = require("../helpers/utils")
const uploadFile = require("../helpers/uploadFile");
// s3
const { uploadFileToS3, uploadAudioToS3 } = require("../helpers/s3");

const util = require('util')
const fs = require('fs')

const unlinkFile = util.promisify(fs.unlink)

// dotenv config
dotenv.config();

module.exports.addEmployee_post = async (req, res, next) => {
  try {
    let employess = await TeamManagement.findOne({ user: req.user._id })
    let teamID = "";
    if (employess) {
      employess.Employee.push(req.body)
      await employess.save();
      teamID = employess._id
    } else {
      const employeee = await new TeamManagement({
        "user": req.user._id,
        Employee: [req.body]
      });
      await employeee.save();
      teamID = employeee._id
      let adminUser = await getUserByID(req.user._id);
      adminUser.teamJoined = teamID;
      await adminUser.save();
    }
    var data = {
      "email": req.body.userInfo.email,
      "name": req.body.userInfo.firstName + " " + req.body.userInfo.lastName,
      "password": await generatePasswordHash(req.body.userInfo.password),
      "teamJoined": teamID
    };
    await new User(data).save();
    const user = await getUserByID(req.user._id);
    const template = {
      subject: "Credentials",
      text: req.body.userInfo
    }
    const SmtpProvider = await SmtpService.findOne({ user: req.user._id });
    if (!SmtpProvider)
      return res.status(400).json({ msg: 'Please add SMTP service first' });
    SendMail(user.email, req.body.userInfo.email, template, SmtpProvider);
    employess = await TeamManagement.findOne({ user: req.user._id })
    return res.status(200).json({ employess });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.team_get = async (req, res, next) => {
  try {
    const team = await TeamManagement.findOne({ "user": req.user._id })
    return res.status(200).send(team);
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.editTeamMember_patch = async (req, res, next) => {
  try {
    const team = await TeamManagement.findOne({ "user": req.user._id })
    if (team && team.Employee) {
      let i;
      for (i = 0; i < team.Employee.length; i++) {
        if ((team.Employee[i]._id.toString().includes(req.params.employeeID))) {
          let user = await User.findOne({ email: team.Employee[i].userInfo.email });
          user.password = await generatePasswordHash(req.body.userInfo.password);
          await user.save();
          req.body.userInfo.email = team.Employee[i].userInfo.email;
          team.Employee[i] = req.body;
          await team.save();
          break;
        }
      }
      return res.status(200).send(team);
    } else {
      return res.status(400).send(`Team Or Team member does not exists`);
    }
  } catch (err) {
    console.error(err.message);
    return res.status(500).send("Server Error");
  }
};

module.exports.deleteTeamMember_delete = async (req, res, next) => {
  try {
    const team = await TeamManagement.findOne({ "user": req.user._id })
    if (team && team.Employee) {
      team.Employee = team.Employee.filter(function (e) {
        if (!(e._id.toString().includes(req.params.employeeID))) {
          return e;
        }
      });
      await team.save();
      const user = await getUserByID(req.params.employeeID);
      if (user) {
        await nullifyTeamOfTheUser(user.email);
      }
      return res.status(200).send(`Team Member Deleted with id ${req.params.employeeID}`);
    } else {
      return res.status(400).send(`Team Or Team member does not exists`);
    }
  } catch (err) {
    console.error(err.message);
    return res.status(500).send("Server Error");
  }
};

module.exports.deleteTeam_delete = async (req, res, next) => {
  try {
    // deleting team
    const team = TeamManagement.findOne({ "user": req.user._id });
    let i = 0;
    for (i = 0; i < team.Employee.length; i++) {
      await nullifyTeamOfTheUser(team.Employee[i].userInfo.email)
    }
    await TeamManagement.findOneAndRemove({ "user": req.user._id });
    res.status(200).send("Team Deleted");
  } catch (err) {
    console.error(err.message);
    return res.status(500).send("Server Error");
  }
};


module.exports.updateMedia_patch = async (req, res, next) => {
  const file = req.file.buffer;
  // checking if audio is selected or not
  if (req.file && req.file !== undefined) {
    if (req.file.length === 0) {
      return res.send({ msg: 'You must select at least 1 audio file.' });
    }
    else if (req.file.length > 1) {
      return res.send({ msg: "Only 1 audio is allowed" });
    }
  } else {
    return res.send({ msg: 'You must select at least 1 audio file.' });
  }
  try {
    const team = await TeamManagement.findOne({ "user": req.user._id })
    if (team && team.Employee) {
      let i;
      for (i = 0; i < team.Employee.length; i++) {
        if ((team.Employee[i]._id.toString().includes(req.params.employeeID))) {
          const result = await uploadAudioToS3(req.params.employeeID, file)
          team.Employee[i].callAndVoiceMailSetting.uploadedFile = result.Location;
          await team.save();
          break;
        }
      }
      return res.status(200).send(team);
    } else {
      return res.status(400).send(`Team Or Team member does not exists`);
    }
  } catch (err) {
    console.error(err.message);
    return res.status(500).send("Server Error");
  }
};





// function to get user by id
async function getUserByID(userID) {
  let user = await User.findOne({ _id: userID });
  if (!user) {
    return null;
  } else {
    return user;
  }
}

// function to get user by id
async function nullifyTeamOfTheUser(email) {
  let user = await User.findOne({ email: email });
  user.teamJoined = null;
  await user.save();
  return;
}

