const Stage = require('../models/Stage');

module.exports.stage_get = async (req, res, next) => {
  const stage = await Stage.find();
  res.status(200).json({ data: stage });
};

module.exports.stage_post = async (req, res, next) => {
  const stage = await Stage.create(req.body);

  res.status(200).json({ data: stage });
};
