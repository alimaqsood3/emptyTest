const Team = require("../models/Team");
const User = require("../models/User");
const {
  team_post_schema,
  team_put_schema,
} = require("../validations/team.validation");
const { getEmployerId } = require("../helpers/utils");

module.exports.team_get = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);
    let teams = await Team.find({ link: userId });

    return res.status(200).json({ data: teams });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.team_post = async (req, res, next) => {
  try {
    const userId = getEmployerId(req.user);
    await team_post_schema.validateAsync(req.body);

    let user = await Team.findOne({ email: req.body.email });
    if (user) {
      return res.status(400).json({ status: 400, data: "User already exists" });
    }

    user = await User.findOne({ email: req.body.email });
    if (user) {
      return res.status(400).json({ status: 400, data: "User already exists" });
    }

    await Team.create({ ...req.body, link: userId });

    return res.status(200).json({ msg: "team Created Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.team_put = async (req, res, next) => {
  try {
    await team_put_schema.validateAsync(req.body);

    const team = await Team.findOneAndUpdate({ _id: req.params.id }, req.body, {
      new: true,
    });

    return res
      .status(200)
      .json({ data: team, msg: "team updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.team_delete = async (req, res, next) => {
  let teams = await Team.deleteOne({ _id: req.params.id });

  return res.status(200).json({ data: teams });
};
