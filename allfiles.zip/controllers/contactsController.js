const Contact = require("../models/Contact");
const ContactActivity = require("../models/ContactActivity");
const uploadFile = require("../helpers/uploadFile");
const path = require("path");
const Tag = require("../models/Tag");
const converter = require('json-2-csv')
const fs = require('fs')
const util = require('util')
const unlinkFile = util.promisify(fs.unlink)

const {
  contact_post_schema,
  contact_put_schema,
} = require("../validations/contact.validation");
const { getCompanyId } = require("../helpers/utils");
const getFilePath = (fileName) =>
  path.resolve(__dirname, `../public/${fileName}`);

module.exports.contact_get = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    let contacts = await Contact.find({ company: companyId }).populate(
      "activity tags"
    );
    return res.status(200).json({ data: contacts });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.contact_post = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    await contact_post_schema.validateAsync(req.body);
    let contactActivityFirst = new ContactActivity();
    contactActivityFirst.type = "creation";
    contactActivityFirst.header = "Contact Created";
    await contactActivityFirst.save();
    const flag = await Contact.findOne({
      $or: [{
        email: req.body.email
      }, {
        phone: req.body.phone
      }]
    })
    if (flag) {
      return res
        .status(200)
        .json({ msg: "Contact with provided email or phone number already exists", data: flag });
    }
    const NEWCONTACT = await Contact.create({
      ...req.body,
      company: companyId,
      activity: contactActivityFirst._id,
    });
    return res
      .status(200)
      .json({ msg: "contact Created Successfully", data: NEWCONTACT });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.contact_put = async (req, res, next) => {
  try {
    await contact_put_schema.validateAsync(req.body);
    const contact = await Contact.findOneAndUpdate(
      { _id: req.params.id },
      req.body,
      { new: true }
    );
    return res
      .status(200)
      .json({ data: contact, msg: "contact updated Successfully" });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};

module.exports.export_contacts_post = async (req, res, next) => {
  const companyId = await getCompanyId(req.user);
  let contacts = await Contact.find({
    $and: [{
      _id: { $in: req.body.ids }
    },
    {
      company: companyId
    },
    ]
  }).populate('tags')
  console.log(contacts)
  let records = contacts
    .filter((item) => item !== null)
    .map(contact => {
      let tagString = "";
      for (let i = 0; i < contact.tags.length; i++) {
        if ((i + 1) < contact.tags.length) {
          tagString = contact.tags[i].name + tagString;
        } else {
          tagString = contact.tags[i].name + ", " + tagString;
        }
      }
      return {
        "First Name": contact.firstName,
        "Last Name": contact.lastName,
        "Email": contact.email,
        "Phone": contact.phone,
        "Contact Type": contact.contactType,
        "Company Name": contact.companyName,
        "Tags": tagString
      }
    });
  const origFileName = `${companyId} - ${Date.now()} - Contacts.csv`;
  converter.json2csv(records, (err, csv) => {
    if (err) {
      throw err
    }
    fs.writeFileSync(`./uploads/${origFileName}`, csv)
  })
  const fileUrl = await uploadFile(origFileName, `./uploads/${origFileName}`);
  await unlinkFile(`./uploads/${origFileName}`);
  return res.status(200).json({ data: fileUrl.Location });
};

module.exports.delete_multi_post = async (req, res, next) => {
  await Contact.deleteMany({
    $and: [{
      _id: { $in: req.body.ids }
    },
    {
      company: req.body.companyID
    },
    ]
  });
  let contacts = await Contact.find({
    company: req.body.companyID
  })
  return res.status(200).json({ data: contacts });
};


module.exports.contact_delete = async (req, res, next) => {
  const companyId = await getCompanyId(req.user);
  await Contact.deleteOne({
    $and: [{
      _id: req.params.id
    }, {
      company: companyId
    }]
  });
  let contacts = await Contact.find({
    company: companyId
  });
  return res.status(200).json({ data: contacts });
};

module.exports.contact_upload = async (req, res, next) => {
  try {
    const companyId = await getCompanyId(req.user);
    await contact_post_schema.validateAsync(req.body);
    let contactActivityFirst = new ContactActivity();
    contactActivityFirst.type = "creation";
    contactActivityFirst.header = "Contact Created";
    await contactActivityFirst.save();
    const flag = await Contact.findOne({
      $or: [{
        email: req.body.email
      }, {
        phone: req.body.phone
      }]
    })
    if (flag) {
      return res
        .status(200)
        .json({ msg: "Contact with provided email or phone number already exists", data: flag });
    }
    for (let i = 0; i < req.body.tags.length; i++) {
      let flagTag = await Tag.findOne({
        $and: [{
          "name": req.body.tags[i]
        }, {
          company: companyId
        }]
      })
      if (flagTag) {
        req.body.tags[i] = flagTag._id
      } else {
        const tag = new Tag({ name: req.body.tags[i], company: companyId })
        await tag.save();
        req.body.tags[i] = tag._id
      }
    }
    const NEWCONTACT = await Contact.create({
      ...req.body,
      company: companyId,
      activity: contactActivityFirst._id,
    });
    return res
      .status(200)
      .json({ msg: "contact Created Successfully", data: NEWCONTACT });
  } catch (e) {
    console.log(e);
    return res.status(500).json({ error: e });
  }
};
