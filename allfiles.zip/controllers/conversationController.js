const SmtpService = require('../models/SmtpService');
const Conversation = require('../models/Conversation');
const SendMail = require('../helpers/mailer');
const ConversationSMSSchema = require('../models/ConversationSms');

module.exports.conversation_post = async (req, res) => {
  const { type, name, subject, email, body } = req.body;

  const SmtpProvider = await SmtpService.findOne({ user: req.user._id });
  if (!SmtpProvider)
    return res.status(400).json({ msg: 'Please add SMTP service first' });
  SendMail(
    'test@salescakemail.com',
    email,
    { subject, body },
    SmtpProvider
  );
  if (!SendMail) {
    return res.status(500).json({ error: 'Email not sent' });
  }
  let conversation;
  try {
    conversation = await Conversation.findOne(
      {
        $and: [
          { user: req.user._id },
          { "emailConversations.email": req.body.email }
        ]
      }
    )
    if (conversation) {
      const newConvo = {
        type: "SENT",
        data: {
          name: req.body.name,
          subject: req.body.subject,
          body: req.body.body
        }
      }
      for (let i = 0; i < conversation.emailConversations.length; i++) {
        if (conversation.emailConversations[i].email.toString().includes(req.body.email)) {
          conversation.emailConversations[i].convo.push(newConvo)
          conversation.emailConversations[i].read.isRead = true;
          break;
        }
      }
      await conversation.save();
    } else {
      conversation = await Conversation.findOne(
        {
          user: req.user._id
        }
      )
      if (!conversation) {
        conversation = await new Conversation({
          user: req.user._id,
          emailConversations: [{
            email: req.body.email,
            convo: [
              {
                type: "SENT",
                data: {
                  name: req.body.name,
                  subject: req.body.subject,
                  body: req.body.body
                }
              }
            ],
            read: {
              isRead: true
            }
          }],
        })
        await conversation.save();
      } else {
        conversation.emailConversations.push({
          email: req.body.email,
          convo: [
            {
              type: "SENT",
              data: {
                name: req.body.name,
                subject: req.body.subject,
                body: req.body.body
              }
            }
          ],
          read: {
            isRead: true
          }
        })
        await conversation.save();
      }
    }
  } catch (error) {
    console.error(error)
  }
  res.status(200).send(conversation);
};

module.exports.conversation_get = async (req, res) => {
  const conversation = await Conversation.find({ user: req.user._id });
  res.status(200).json({ data: conversation });
};


module.exports.conversation_patch_email = async (req, res) => {
  let conversation = await Conversation.findOne(
    {
      $and: [
        { user: req.user._id },
        { "emailConversations.email": req.body.email }
      ]
    }
  )
  if (!conversation) {
    return res.status(400).send("Not found");
  }
  for (let i = 0; i < conversation.emailConversations.length; i++) {
    if (conversation.emailConversations[i].email.toString().includes(req.body.email)) {
      conversation.emailConversations[i].read.isRead = req.body.isRead;
      break;
    }
  }
  await conversation.save();
  res.status(200).json({ data: conversation });
};

//Conversation with SMS Chunk------------------------------------------------------------------
const accountSid = 'AC7fbdfbe89073e71671ae410a595f3831';
const authToken = '0b8fcc56dc9a9cc320be807e9f3a0533 ';
const client = require('twilio')(accountSid, authToken);

module.exports.conversation_sms_post = async (req, res, next) => {
  const { to, from, discription } = req.body;
  console.log
  let conversation;
  try {
    conversation = await Conversation.findOne(
      {
        $and: [
          { user: req.user._id },
          { "smsConversations.phoneNumber": to }
        ]
      }
    )
    if (conversation) {
      const newConvo = {
        type: "SENT",
        data: discription
      }
      for (let i = 0; i < conversation.smsConversations.length; i++) {
        if (conversation.smsConversations[i].phoneNumber.toString().includes(to)) {
          conversation.smsConversations[i].convo.push(newConvo)
          conversation.smsConversations[i].read.isRead = true;
          break;
        }
      }
      await conversation.save();
    } else {
      conversation = await Conversation.findOne(
        {
          user: req.user._id
        }
      )
      if (!conversation) {
        conversation = await new Conversation({
          user: req.user._id,
          smsConversations: [{
            phoneNumber: to,
            convo: [
              {
                type: "SENT",
                data: discription
              }
            ],
            read: {
              isRead: true
            }
          }],
        })
        await conversation.save();
      } else {
        conversation.smsConversations.push({
          phoneNumber: to,
          convo: [
            {
              type: "SENT",
              data: discription
            }
          ],
          read: {
            isRead: true
          }
        })
        await conversation.save();
      }
    }
  } catch (error) {
    console.error(error)
  }
  res.status(200).send(conversation);
};

module.exports.conversation_get = async (req, res) => {
  const conversation = await Conversation.find({ user: req.user._id });
  res.status(200).json({ data: conversation });
};

// change read status of SMS
module.exports.conversation_patch_sms = async (req, res) => {
  let conversation = await Conversation.findOne(
    {
      $and: [
        { user: req.user._id },
        { "smsConversations.phoneNumber": req.body.to }
      ]
    }
  )
  if (!conversation) {
    return res.status(400).send("Not found");
  }
  for (let i = 0; i < conversation.smsConversations.length; i++) {
    if (conversation.smsConversations[i].phoneNumber.toString().includes(req.body.to)) {
      conversation.smsConversations[i].read.isRead = req.body.isRead;
      break;
    }
  }
  await conversation.save();
  res.status(200).json({ data: conversation });
};


module.exports.conversation_patch = async (req, res) => {
  let conversation = await Conversation.findOne(
    {
      $and: [
        { user: req.user._id },
        { "smsConversations.phoneNumber": req.body.to }
      ]
    }
  )
  if (!conversation) {
    return res.status(400).send("Not found");
  }
  for (let i = 0; i < conversation.emailConversations.length; i++) {
    if (conversation.emailConversations[i].email.toString().includes(req.body.email)) {
      conversation.emailConversations[i].read.isRead = req.body.isRead;
      break;
    }
  }
  await conversation.save();
  client.messages
    .create({ body: 'Hi there', from: '+15017122661', to: '+923349277873' })
    .then(message => {
      console.log("Hellow")
      console.log(message.sid)
    });
  return res.status(200).send("conversationSms");
};

module.exports.conversation_sms_get = async (req, res, next) => {
  // ConversationSMSSchema.findById(req.params.id, function (err, dba) {
  //   if (err) res.send(err);
  //   res.json(dba);
  // });
  // const conversationSms = await ConversationSMSSchema.find({ user: req.user._id });
  // res.status(200).json({ data: conversationSms });
};

// try{
//   const userId = ConversationSMSSchema(req.user);
//   let smsData = await ConversationSMSSchema.find({ fromUser: userId });
//   return res.status(200).json(smsData);

// }catch(err){
//   return res.status(500).json(err);
// }
// }
