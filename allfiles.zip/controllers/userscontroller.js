const validator = require("validator");
const User = require("../models/User");
const Company = require("../models/Company");
const mongoose = require("mongoose");
const generateToken = require("../helpers/generatetoken");
const passport = require("passport");

const COMPANY_STAGES = [
  "Short List",
  "Internal Screening",
  "Candidate Submission",
  "Interview Process",
  "Rejected",
  "Offer Extended",
  "Offer Accepted",
  "Offer Declined",
  "Candidate Start Work",
  "Guarantee Expired",
  "Delete",
];

module.exports.register_post = async (req, res) => {
  try {
    // Fetch Data From Request
    const name = req.body.name ? req.body.name.trim() : "";
    const email = req.body.email ? req.body.email.trim() : "";
    const password = req.body.password ? req.body.password.trim() : "";

    // Validators
    const errors = [];
    if (
      validator.isEmpty(name) ||
      validator.isEmpty(email) ||
      validator.isEmpty(password)
    ) {
      errors.push("name, email and password is required");
    }
    if (!validator.isEmail(email)) errors.push("Email is not valid");
    if (!validator.isByteLength(password, { min: 6 }))
      errors.push("Password must be at least 6 characters");

    if (errors.length) {
      return res.status(400).json({ status: 400, data: errors.join("\n") });
    }

    // Process
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ status: 400, data: "User already exists" });
    }

    user = new User({
      name,
      email,
      password,
    });
    await user.save();

    let company = new Company();
    company.companyName = "No Name";
    company.user = user._id;
    company.stages = COMPANY_STAGES.map((item) => {
      return {
        name: item,
      };
    });
    await company.save();
    console.log(generateToken(user));
    return res.status(200).json({ status: 200, data: generateToken(user) });
  } catch (error) {
    console.log(" error", error.stack);
    res.status(500).json({ status: 500, data: "Server Error" });
  }
};

module.exports.addTeam = async (req, res) => {
  const { team, name } = req.body;
  const randomPassword = Math.random().toString(36).slice(-8);

  //Checking If Email Already Exist
  const userExists = await User.findOne({ email: team });
  if (userExists) {
    return res.status(400).json({ status: 400, data: "User already exists" });
  }
  const user = await User.findById(req.user._id);
  const newUser = new User({
    name: name,
    email: team,
    password: randomPassword,
    employerId: req.user._id,
  });

  const sess = await mongoose.startSession();
  sess.startTransaction();
  await newUser.save({ session: sess });
  user.team.push(newUser._id);
  await user.save({ session: sess });
  await sess.commitTransaction();
  res.status(201).json({ status: "success", user: newUser });
};


