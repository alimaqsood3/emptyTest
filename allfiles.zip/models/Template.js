const mongoose = require("mongoose");

const templateSchema = new mongoose.Schema({
  name: String,
  subject: String,
  body: String,
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
  },
});

templateSchema.set("toObject", { virtuals: true });
templateSchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("Template", templateSchema);
