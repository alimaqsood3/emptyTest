const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const contactActivitySchema = new Schema(
  {
    type: {
      type: String,
    },
    header: {
      type: String,
    },
    subheader: {
      type: String,
    },
  },
  { timestamps: true }
);

const ContactActivity = mongoose.model(
  "ContactActivity",
  contactActivitySchema
);
module.exports = ContactActivity;
