const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const companyDataSchema = new Schema ({
    companyName:{
        type: String,
        required: true
    },
    companyEmail:{
        type: String,
        required: true
    },
    companyPhone:{
        type: String,
        required: true
    },
    companyWebsite:{
        type: String,
        required: true
    },
    companyNiche:{
        type: String,
        required: true
    }
})

const CompanyData = mongoose.model("CompanyData", companyDataSchema);
module.exports = CompanyData;