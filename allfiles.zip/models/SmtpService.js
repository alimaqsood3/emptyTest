const mongoose = require('mongoose');

// Create User Schema
const smtpSchema = new mongoose.Schema({
  defaultProvider: { type: Boolean, default: false },
  providerName: String,
  providerType: String,
  host: String,
  smtpServer: String,
  imapServer: String,
  portNumber: String,
  imapPortNumber: String,
  username: String,
  email: String,
  password: String,
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
});

smtpSchema.set('toObject', { virtuals: true });
smtpSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('SmtpProvider', smtpSchema);
