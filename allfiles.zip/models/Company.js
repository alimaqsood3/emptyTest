const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const companyProfileSchema = new Schema(
  {
    companyName: {
      type: String,
      required: true,
    },
    companyEmail: {
      type: String,
    },
    companyPhone: {
      type: String,
    },
    companyWebsite: {
      type: String,
    },
    companyNiche: {
      type: String,
    },
    companyLogo: {
      type: String,
    },
    address: {
      type: String,
    },
    city: {
      type: String,
    },
    state: {
      type: String,
    },
    country: {
      type: String,
    },
    timeZone: {
      type: String,
    },
    zipCode: {
      type: String,
    },
    voiceAudio: {
      type: String,
    },
    voiceTimeout: {
      type: Number,
    },
    missedCall: {
      type: Boolean,
    },
    duplicateContacts: { type: Boolean, default: false },
    duplicateOpportunity: { type: Boolean, default: false },
    disableContactTimezone: { type: Boolean, default: false },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    stages: [
      {
        name: String,
        isVisibleInFunnel: {
          type: Boolean,
          default: false,
        },
        isVisibleInPie: {
          type: Boolean,
          default: false,
        },
      },
    ],
  },
  { timestamps: true }
);

const Company = mongoose.model("Company", companyProfileSchema);
module.exports = Company;
