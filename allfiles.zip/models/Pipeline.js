const mongoose = require("mongoose");

const pipelineSchema = new mongoose.Schema({
  name: String,
  isVisibleInFunnel: {
    type: Boolean,
    default: false,
  },
  isVisibleInPie: {
    type: Boolean,
    default: false,
  },
  stages: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Stage",
    },
  ],
  opportunities: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Oppurtunity",
    },
  ],
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  assignTo: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Team",
    },
  ],
});

pipelineSchema.set("toObject", { virtuals: true });
pipelineSchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("Pipeline", pipelineSchema);
