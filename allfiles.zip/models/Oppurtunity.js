const mongoose = require("mongoose");

// Create User Schema
const opportunitySchema = new mongoose.Schema({
  addCandidateToExistingPlacement: {
    contactInfo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Contact",
    },
    opportunityInfo: {
      opportunityName: [String],
      pipeline: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Pipeline",
      },
      stage: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Stage",
      },
      status: {
        type: String,
        enum: ["OPEN", "CLOSED"],
      },
      leadValue: String,
      owner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Team",
      },
      source: String,
    }
  },
  addNewPlacementOpportunity: {
    role: String,
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },
    assignedTo: String,
    salary: String,
    placementFee: String,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
});

opportunitySchema.set("toObject", { virtuals: true });
opportunitySchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("Oppurtunity", opportunitySchema);
