const mongoose = require("mongoose");

// Create User Schema
const tagSchema = new mongoose.Schema({
  name: String,
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
  },
});

tagSchema.set("toObject", { virtuals: true });
tagSchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("Tag", tagSchema);
