const mongoose = require("mongoose");

const conversationSchema = mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',

  },
  emailConversations: [
    {
      email: {
        type: String,
      },
      convo: [{
        type: {
          type: String,
          enum: ["SENT", "RECEIVED"]
        },
        data: {
          name: {
            type: String,
          },
          subject: {
            type: String,
          },
          body: {
            type: String,
          },
        },
        date: {
          type: Date,
          default: Date.now
        }
      }],
      read: {
        isRead: {
          type: Boolean,
          default: false
        },
        date: {
          type: Date,
          default: Date.now
        }
      }
    }
  ],
  smsConversations: [
    {
      phoneNumber: {
        type: String,
      },
      convo: [{
        type: {
          type: String,
          enum: ["SENT", "RECEIVED"]
        },
        data: {
          type: String,
        },
        date: {
          type: Date,
          default: Date.now
        }
      }],
      read: {
        isRead: {
          type: Boolean,
          default: false
        },
        date: {
          type: Date,
          default: Date.now
        }
      },
    }
  ],
  callConversations: [
    {
      callingPhoneNumber: {
        type: String,
      },
      convo: [{
        type: {
          type: String,
          enum: ["INGOING", "OUTGOING"]
        },
        data: {
          type: String,
        },
        ourNumber: {
          type: String,
        },
        date: {
          type: Date,
          default: Date.now
        }
      }],
      read: {
        isRead: {
          type: Boolean,
          default: false
        },
        date: {
          type: Date,
          default: Date.now
        }
      }
    }
  ]
})

module.exports = mongoose.model('Conversation', conversationSchema);


// const mongoose = require("mongoose");

// const conversationSchema = mongoose.Schema({
//   user: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: 'User',
//
//   },
//   emailConversations: {
//     email: {
//       type: String,
//
//
//     },
//     convo: [{
//       type: {
//         type: String,
//
//         enum: ["SENT", "RECEIVED"]
//       },
//       data: {
//         name: {
//           type: String,
//
//         },
//         subject: {
//           type: String,
//
//         },
//         body: {
//           type: String,
//
//         },
//       },
//       date: {
//         type: Date,
//         default: Date.now
//       }
//     }],
//     read: {
//       isRead: {
//         type: Boolean,
//
//         default: false
//       },
//       date: {
//         type: Date,
//         default: Date.now
//       }
//     }
//   },
//   smsConversations: {
//     number: {
//       type: String,
//
//
//     },
//     convo: [{
//       type: {
//         type: String,
//
//         enum: ["SENT", "RECEIVED"]
//       },
//       data: {
//         type: String,
//
//       },
//       date: {
//         type: Date,
//         default: Date.now
//       }
//     }],
//     read: {
//       isRead: {
//         type: Boolean,
//
//         default: false
//       },
//       date: {
//         type: Date,
//         default: Date.now
//       }
//     },
//   },
//   callConversations: {
//     number: {
//       type: String,
//
//
//     },
//     convo: [{
//       type: {
//         type: String,
//
//         enum: ["INGOING", "OUTGOING"]
//       },
//       data: {
//         type: String,
//
//       },
//       ourNumber: {
//         type: String,
//
//       },
//       date: {
//         type: Date,
//         default: Date.now
//       }
//     }]
//   }
// })

// module.exports = mongoose.model('Conversation', conversationSchema);
