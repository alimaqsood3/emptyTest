const mongoose = require("mongoose")
const Schema = mongoose.Schema;

const campaignSchema = mongoose.Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: true
  },
  status: {
    type: String,
    required: true,
    default: "DRAFT",
    enum: ['DRAFT', 'PUBLISHED']
  },
  configuration: {
    sentOndays: [{
      type: String,
      enum: ["MONDAY", 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']
    }],
    startTime: {
      type: String,
    },
    endTime: {
      type: String,
    },
    fromUser: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    stopOnResponse: {
      type: Boolean,
      default: false
    },
  },
  date: {
    type: Date,
    default: Date.now
  }
})

module.exports = mongoose.model("Campaign", campaignSchema);