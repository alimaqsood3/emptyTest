const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

// Create User Schema
const userSchema = new mongoose.Schema({
  name: String,
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
  },
  type: { type: String, default: "employer" },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
    select: false
  },
  team: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "Team",
  }],
  teamJoined: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "TeamManagement",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Encrypt the Password before Saving to DB
userSchema.pre("save", async function (next) {
  const user = this;
  if (!user.isModified("password")) return next();
  const hash = await bcrypt.hash(user.password, 10);
  this.password = hash;
  next();
});

// Encrypt the Password before Updating
userSchema.pre("findOneAndUpdate", async function (next) {
  const updatedInfo = this.getUpdate();
  if (updatedInfo.password) {
    this._update.password = await bcrypt.hash(updatedInfo.password, 10);
  }
  next();
});

// Check if the password is correct
userSchema.methods.isValidPassword = async function (password,hash) {
  console.log(password)
  console.log(this.password)
  return await bcrypt.compare(password, hash);

};

userSchema.virtual("fullName").get(function () {
  return this.firstName + " " + this.lastName;
});

userSchema.set("toObject", { virtuals: true });
userSchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("User", userSchema);
