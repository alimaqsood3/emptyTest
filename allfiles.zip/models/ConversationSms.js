const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const conversationSMSSchema = new mongoose.Schema  ({
    person_number:{
        type: String,
        require: true
    },
     our_number:{
        type: String,
        require: true
    },
     discription:{
        type: String,
        require: true
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }
})

module.exports = mongoose.model("ConversationSms", conversationSMSSchema); 
