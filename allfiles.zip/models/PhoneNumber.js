const mongoose = require("mongoose");

// Create User Schema
const phoneNumberSchema = new mongoose.Schema({
  outBoundNumber: { type: Boolean, default: false },
  friendlyName: String,
  phoneNumber: String,
  forwardingNumber: String,
  numberSid: String,
  timeout: String,
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
  },
});

phoneNumberSchema.set("toObject", { virtuals: true });
phoneNumberSchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("PhoneNumber", phoneNumberSchema);
