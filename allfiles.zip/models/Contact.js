const mongoose = require("mongoose");

// make cotacts list model
const contactsSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true,
  },
  lastName: String,
  email: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  tags: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Tag",
    },
  ],
  contactType: {
    type: String,
  },
  companyName: String,
  notes: String,
  source: String,
  activity: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ContactActivity",
    },
  ],
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
  },
});

module.exports = mongoose.model("Contact", contactsSchema);
