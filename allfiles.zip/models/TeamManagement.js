const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const teamManagementSchema = mongoose.Schema({
    user: {
        type: Schema.Types.ObjectId,
        ref: 'User'
    },
    Employee: [
        {
            userInfo: {
                firstName: {
                    type: String,
                    required: true
                },
                lastName: {
                    type: String,
                    required: true
                },
                email: {
                    type: String,
                    required: true,
                    unique: true
                },
                phone: {
                    type: String,
                    required: true
                },
                extension: {
                    type: String,
                    required: true
                },
                password: {
                    type: String,
                    required: true
                },
                signatureAndData: {
                    signature: {
                        type: String,
                        required: true
                    },
                    enableSignature: {
                        type: Boolean,
                        required: true,
                        default: false
                    },
                    includeSignature: {
                        type: Boolean,
                        required: true,
                        default: false
                    },
                },
            },
            userPermissions: {
                type: Boolean,
                required: true
            },
            userRoles:
            {
                type: String,
                required: true
            },
            callAndVoiceMailSetting: {
                tiwilioNumber: {
                    type: String,
                    required: true
                },
                incomingCallTimeout: {
                    type: String,
                    required: true
                },
                uploadedFile: {
                    type: String,
                    required: true
                }
            }
        }
    ],
    date: {
        type: Date,
        default: Date.now
    }
})

const TeamManagement = mongoose.model('TeamManagement', teamManagementSchema);
module.exports = TeamManagement