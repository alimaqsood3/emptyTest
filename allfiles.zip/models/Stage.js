const mongoose = require('mongoose');

const stageSchema = new mongoose.Schema({
  name: String,
  isVisibleInFunnel: {
    type: Boolean,
    default: false,
  },
  isVisibleInPie: {
    type: Boolean,
    default: false,
  },
});

stageSchema.set('toObject', { virtuals: true });
stageSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Stage', stageSchema);
