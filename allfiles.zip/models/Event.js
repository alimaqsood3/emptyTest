const mongoose = require("mongoose")
const Schema = mongoose.Schema;

const eventSchema = mongoose.Schema({
    campaign: {
        type: Schema.Types.ObjectId,
        ref: 'Campaign',
        required: true
    },
    type: {
        type: String,
        required: true,
        enum: ['EMAIL', 'SMS']
    },
    emailEvent: {
        nameOfEmail: {
            type: String
        },
        subjectLine: {
            type: String
        },
        attachment: {
            type: String
        },
        body: {
            type: String
        },
    },
    smsEvent: {
        from: {
            type: String
        },
        to: {
            type: String
        },
        text: {
            type: String
        }
    },
    date: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model("Event", eventSchema);