const joi = require("joi");

exports.template_post_schema = joi.object().keys({
  name: joi.string().required().messages({
    "any.required": "Name is Required",
  }),
  subject: joi.string().required().messages({
    "any.required": "Subject is Required",
  }),
  body: joi.string().required().messages({
    "any.required": "Body is Required",
  })
});

exports.template_put_schema = joi.object().keys({
  name: joi.string().required().messages({
    "any.required": "Name is Required",
  }),
  body: joi.string().required().messages({
    "any.required": "Body is Required",
  }),
  subject: joi.string().required().messages({
    "any.required": "Subject is Required",
  })
});
