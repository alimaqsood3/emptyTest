const joi = require("joi");

exports.contact_post_schema = joi.object().keys({
  firstName: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .required()
    .messages({
      "string.required": "First Name is required",
    }),
  lastName: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .messages({
      "any.required": "Last Name is required",
    }),
  email: joi
    .string()
    .email()
    .regex(
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    ),
  phone: joi.number().integer().required().messages({
    "number.integer": "Phone number must be an integer",
    "number.min": "Phone number must be at least 11 digits",
    "number.max": "Phone number must be at most 11 digits",
    "any.required": "Phone number is required",
  }),

  tags: joi.array(),
  contactType: joi.string(),
  companyName: joi.string(),
  source: joi.string().optional().allow(""),
});

exports.contact_put_schema = joi.object().keys({
  firstName: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .required()
    .messages({
      "string.required": "First Name is required",
    }),
  lastName: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .messages({
      "any.required": "Last Name is required",
    }),
  email: joi
    .string()
    .email()
    .regex(
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    ),
  phone: joi.number().integer().required().messages({
    "number.integer": "Phone number must be an integer",
    "number.min": "Phone number must be at least 11 digits",
    "number.max": "Phone number must be at most 11 digits",
    "any.required": "Phone number is required",
  }),

  tags: joi.array(),
  contactType: joi.string(),
  companyName: joi.string(),
  source: joi.string(),
});
