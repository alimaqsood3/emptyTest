const joi = require("joi");

exports.company_put_schema = joi.object().keys({
  companyName: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .allow(""),
  companyEmail: joi
    .string()
    .email()
    .regex(
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    )
    .optional()
    .allow(""),
  companyPhone: joi.number().integer().allow("").messages({
    "number.integer": "Phone number must be an integer",
    "number.min": "Phone number must be at least 11 digits",
    "number.max": "Phone number must be at most 11 digits",
    "any.required": "Phone number is required",
  }),
  companyWebsite: joi.string().optional().allow(""),
  companyNiche: joi.string().optional().allow(""),
});

exports.company_address_put_schema = joi.object().keys({
  address: joi.string().required(),
  state: joi.string().required(),
  city: joi.string().required(),
  zipCode: joi.string().required(),
  timeZone: joi.string().required(),
  country: joi.string().required(),
});

