const joi = require("joi");

exports.opportunity_post_add_candidate_to_existing_placement_schema = joi.object().keys({
  addCandidateToExistingPlacement: joi.object({
    opportunityInfo: joi.object({
      opportunityName: joi.string().required().messages({
        "string.required": "Name is required",
      }),
      pipeline: joi.string().messages({
        "any.required": "Pipeline is required",
      }),
      stage: joi.string().messages({
        "any.required": "Stage is required",
      }),
      leadValue: joi.string().messages({
        "any.required": "Lead Value is required",
      }),
      status: joi
        .string()
        .messages({
          "any.required": "Status is required",
        }),
      owner: joi.string(),
      source: joi
        .string()
        .messages({
          "any.required": "Source is required",
        })
    }),
    contactInfo: joi.object({
      contactName: joi
        .string()
        .optional()
        .allow(""),
      companyName: joi
        .string()
        .optional()
        .allow(""),
      contactEmail: joi
        .string()
        .email()
        .optional(),
      contactPhone: joi.string().optional().allow(""),
      tags: joi.array().items(joi.string())
    })
  })
});

exports.opportunity_post_add_new_placement_opportunity_schema = joi.object().keys({
  addNewPlacementOpportunity: joi.object({
    role: joi.string().required().messages({
      "string.required": "Role is required",
    }),
    company: joi.string().messages({
      "any.required": "Company is required",
    }),
    assignedTo: joi.string().required().messages({
      "string.required": "Assigned to is required",
    }),
    salary: joi.string().messages({
      "any.required": "Salary is required",
    }),
    placementFee: joi.string().required().messages({
      "string.required": "Placement Fee to is required",
    })
  })
});

exports.opportunity_put_schema = joi.object().keys({
  name: joi.string().required().messages({
    "string.required": "Name is required",
  }),
  stage: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .messages({
      "any.required": "Stage is required",
    }),
  status: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .messages({
      "any.required": "Status is required",
    }),
  leadValue: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .messages({
      "any.required": "Lead Value is required",
    }),
  source: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .messages({
      "any.required": "Source is required",
    }),
  owner: joi.string(),
  pipeline: joi.string(),
  contact: joi.string().optional().allow(""),
});
