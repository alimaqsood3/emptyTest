const joi = require("joi");

exports.companyData_path_schema = joi.object().keys({
    companyName: joi
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .required()
    .messages({
      "string.required": "Company Name is required",
    }),
    companyEmail: joi
    .string()
    .email()
    .regex(
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    )
    .messages({
        "string.required": "Company Email is required",
      }),
    companyPhone: joi.number().integer().required().messages({
        "number.integer": "Phone number must be an integer",
        "number.min": "Phone number must be at least 11 digits",
        "number.max": "Phone number must be at most 11 digits",
        "any.required": "Phone number is required",
    }),
    companyWebsite: joi 
    .string()
    .required()
    .messages({
      "string.required": "Company Website is required",
    }),
    companyNiche: joi 
    .string()
    .regex(/^[a-zA-Z ]+$/)
    .required()
    .messages({
      "string.required": "Company Niche is required",
    }),

})
