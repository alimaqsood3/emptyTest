const joi = require('joi');
const User = require('../models/User')

const editEmployeeValidator = async (req, res, next) => {
    const { body } = req;
    const userRoless = ['ADMIN', 'USER'];
    const editEmployeeValidatorSchema = joi.object({
        userInfo: joi.object({
            firstName: joi.string().required(),
            lastName: joi.string().required(),
            phone: joi.string().required(),
            extension: joi.string().required(),
            password: joi.string().required(),
            signatureAndData: joi.object({
                signature: joi.string().required(),
                enableSignature: joi.boolean().required(),
                includeSignature: joi.boolean().required()
            })
        }).required(),
        userPermissions: joi.boolean().required(),
        userRoles: joi.string().valid(...Object.values(userRoless)).required(),
        callAndVoiceMailSetting: joi.object({
            tiwilioNumber: joi.string().required(),
            incomingCallTimeout: joi.string().required(),
            uploadedFile: joi.string().required()
        }).required(),
    });

    try {
        await editEmployeeValidatorSchema.validateAsync(body);
    } catch (err) {
        return res.status(400).send({
            error: err.details[0].message
        });
    }
    next();
};


module.exports = editEmployeeValidator
