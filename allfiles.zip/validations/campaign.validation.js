const joi = require("joi");

const statusType = ['DRAFT', 'PUBLISHED']

exports.campaign_post_schema = joi.object().keys({
  name: joi.string().min(3).max(50).required().messages({
    "string.min": " Name must be at least 3 characters",
    "string.max": "Name must be at most 50 characters",
    "any.required": "Name is required",
    "string.empty": "Please enter Mail name",
  }),
});

exports.campaign_patch_schema = joi.object().keys({
  name: joi.string().min(3).max(50).messages({
    "string.min": " Name must be at least 3 characters",
    "string.max": "Name must be at most 50 characters",
    "any.required": "Name is required",
    "string.empty": "Please enter Mail name",
  }),
  status: joi.string().valid(...Object.values(statusType)),
  configuration: joi.object({
    sentOndays: joi.array().required(),
    startTime: joi.string().required(),
    endTime: joi.string().required(),
    fromUser: joi.string().required(),
    stopOnResponse: joi.boolean().required()
  })
});

exports.campaign_put_schema = joi.object().keys({
  sendOnDays: joi.string().required().messages({
    "any.required": "Send on Days is Required",
  }),
  startTime: joi.string().required().messages({
    "any.required": "Start Time is Required",
  }),
  endTime: joi.string().required().messages({
    "any.required": "End Time is Required",
  }),
  stopOnResponse: joi.boolean().required().messages({
    "any.required": "Stop on Response is Required",
  }),
  fromUser: joi.string().required().messages({
    "any.required": "From User is Required",
  }),
});
