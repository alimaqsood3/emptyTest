const joi = require('joi');

exports.smtpService_post_schema = joi.object().keys({
  defaultProvider: joi.boolean().required().messages({
    'any.required': 'Default Provider is Required',
  }),
  providerName: joi.string().required().messages({
    'any.required': 'Provider Name is Required',
  }),
  host: joi.string().required().messages({
    'any.required': 'Host is Required',
  }),
  providerType: joi.string().required().messages({
    'any.required': 'Provider Type is Required',
  }),
  smtpServer: joi.string().required().messages({
    'any.required': 'Smtp Server is Required',
  }),
  imapServer: joi.string().required().messages({
    'any.required': 'IMAP Server is Required',
  }),
  username: joi.string().required().messages({
    'any.required': 'username is Required',
  }),
  portNumber: joi.string().required().messages({
    'any.required': 'Port Number is Required',
  }),
  imapPortNumber: joi.string().required().messages({
    'any.required': 'IMAP Port Number is Required',
  }),
  email: joi.string().required().messages({
    'any.required': 'email is Required',
  }),
  password: joi.string().required().messages({
    'any.required': 'password is Required',
  }),
});

exports.smtpService_put_schema = joi.object().keys({
  defaultProvider: joi.boolean().required().messages({
    'any.required': 'Default Provider is Required',
  }),
  providerName: joi.string().required().messages({
    'any.required': 'Provider Name is Required',
  }),
  providerType: joi.string().required().messages({
    'any.required': 'Provider Type is Required',
  }),
  smtpServer: joi.string().required().messages({
    'any.required': 'Smtp Server is Required',
  }),
  imapServer: joi.string().required().messages({
    'any.required': 'IMAP Server is Required',
  }),
  username: joi.string().required().messages({
    'any.required': 'username is Required',
  }),
  portNumber: joi.string().required().messages({
    'any.required': 'Port Number is Required',
  }),
  imapPortNumber: joi.string().required().messages({
    'any.required': 'IMAP Port Number is Required',
  }),
  email: joi.string().required().messages({
    'any.required': 'email is Required',
  }),
  password: joi.string().required().messages({
    'any.required': 'password is Required',
  }),
});
