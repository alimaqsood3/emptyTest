const joi = require("joi");

exports.tag_post_schema = joi.object().keys({
  name: joi.string().required().messages({
    "any.required": "Name is Required",
  }),
});

exports.tag_put_schema = joi.object().keys({
  name: joi.string().required().messages({
    "any.required": "Name is Required",
  }),
});
