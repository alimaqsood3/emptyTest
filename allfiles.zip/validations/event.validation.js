const joi = require("joi");
const eventType = ['EMAIL', 'SMS']

exports.event_post_schema = joi.object().keys({
    campaign: joi.string().required(),
    type: joi.string().valid(...Object.values(eventType)).required(),
    emailEvent: joi.object({
        nameOfEmail: joi.string().required(),
        subjectLine: joi.string().required(),
        attachment: joi.string(),
        body: joi.string().required(),
    }),
    smsEvent: joi.object({
        from: joi.string().required(),
        to: joi.string().required(),
        text: joi.string().required()
    })
});

