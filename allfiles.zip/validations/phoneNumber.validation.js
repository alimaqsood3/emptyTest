const joi = require("joi");

exports.phoneNumber_post_schema = joi.object().keys({
  outBoundNumber: joi.boolean().optional().allow(""),
  friendlyName: joi.string().required().messages({
    "any.required": "Name is Required",
  }),
  phoneNumber: joi.string().required().messages({
    "any.required": "Phone Number is Required",
  }),
  forwardingNumber: joi.string().optional().allow(""),
  timeout: joi.string().optional().allow(""),
});

exports.phoneNumber_put_schema = joi.object().keys({
  outBoundNumber: joi.boolean().optional().allow(""),
  friendlyName: joi.string().required().messages({
    "any.required": "Name is Required",
  }),
  forwardingNumber: joi.string().optional().allow(""),
  timeout: joi.string().optional().allow(""),
});
