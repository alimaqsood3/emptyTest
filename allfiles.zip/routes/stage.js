const express = require('express');
const router = express.Router();
const stageController = require('../controllers/stageController');
const authMw = require('../config/apiauth');

router.post(
  '/api/v1/stage',
  authMw.ensureAuthenticated,
  stageController.stage_post
);
router.get(
  '/api/v1/stage',
  authMw.ensureAuthenticated,
  stageController.stage_get
);

module.exports = router;
