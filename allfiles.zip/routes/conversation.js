const express = require('express');
const router = express.Router();
const conversationController = require('../controllers/conversationController');
const authMw = require('../config/apiauth');

//email requests
router.post(
  '/api/v1/conversation',
  authMw.ensureAuthenticated,
  conversationController.conversation_post
);

router.get(
  '/api/v1/conversation',
  authMw.ensureAuthenticated,
  conversationController.conversation_get
);

router.patch(
  '/api/v1/conversationEmail',
  authMw.ensureAuthenticated,
  conversationController.conversation_patch_email
);

router.patch(
  '/api/v1/conversationSMS',
  authMw.ensureAuthenticated,
  conversationController.conversation_patch_sms
);

//sms requests

router.post(
  '/api/v1/conversationSmsPost',
  authMw.ensureAuthenticated,
  conversationController.conversation_sms_post


)
router.get(
  '/api/v1/conversationSmsGet/:id',
  authMw.ensureAuthenticated, 
  conversationController.conversation_sms_get
);


module.exports = router;
