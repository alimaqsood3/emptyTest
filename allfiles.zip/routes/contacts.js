const express = require("express");
const router = express.Router();
const contactController = require("../controllers/contactsController");
const authMw = require("../config/apiauth");

// User Routes
router.post(
  "/api/v1/contact",
  authMw.ensureAuthenticated,
  contactController.contact_post
);

router.post(
  "/api/v1/contact/upload",
  authMw.ensureAuthenticated,
  contactController.contact_upload
);

router.post(
  "/api/v1/contact/delete_multi",
  authMw.ensureAuthenticated,
  contactController.delete_multi_post
);

router.post(
  "/api/v1/contact/export",
  authMw.ensureAuthenticated,
  contactController.export_contacts_post
);

router.get(
  "/api/v1/contact",
  authMw.ensureAuthenticated,
  contactController.contact_get
);

router.patch(
  "/api/v1/contact/:id",
  authMw.ensureAuthenticated,
  contactController.contact_put
);

router.delete(
  "/api/v1/contact/:id",
  authMw.ensureAuthenticated,
  contactController.contact_delete
);

module.exports = router;
