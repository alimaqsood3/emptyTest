const express = require("express");
const router = express.Router();
const teamManagementController = require("../controllers/teamManagementController");
const authMw = require("../config/apiauth");
const addEmployeeValidator = require("../validations/teamManagement.addEmployee.validation")
const editEmployeeValidator = require("../validations/teamManagement.editEmployee.validation")
const uploadFiles = require("../helpers/upload")
const { memoryStorage } = require('multer')
const multer = require('multer')
const storage = memoryStorage();
const upload = multer({ storage })

// User Routes

// @route    POST api/v1/teamManagement/addEmployee
// @desc     Add Employee to the team
// @access   Private / Admin only route

router.post(
  "/api/v1/teamManagement/addEmployee",
  [authMw.ensureAuthenticated,
    addEmployeeValidator],
  teamManagementController.addEmployee_post
);

// @route    DELETE api/v1/teamManagement/
// @desc     Delete team
// @access   Private / Admin only route

router.delete(
  "/api/v1/teamManagement/",
  authMw.ensureAuthenticated,
  teamManagementController.deleteTeam_delete
);

// @route    DELETE api/v1/teamManagement/:employeeID
// @desc     Delete Employee from the team
// @access   Private / Admin only route

router.delete(
  "/api/v1/teamManagement/teamMember/:employeeID",
  authMw.ensureAuthenticated,
  teamManagementController.deleteTeamMember_delete
);

// @route    PATCH /api/v1/teamManagement/edit/:employeeID
// @desc     Edit Employee from the team
// @access   Private / Admin only route

router.patch(
  "/api/v1/teamManagement/edit/:employeeID",
  [authMw.ensureAuthenticated,
    editEmployeeValidator],
  teamManagementController.editTeamMember_patch
);

// @route    PATCH /api/v1/teamManagement/updateMedia/edit/:employeeID
// @desc     Edit Employee from the team
// @access   Private / Admin only route


router.patch(
  "/api/v1/teamManagement/updateMedia/:employeeID",
  [authMw.ensureAuthenticated,
  upload.single("audio")
  ],
  teamManagementController.updateMedia_patch
);

// @route    GET api/v1/teamManagement/
// @desc     Get Team Of The Admin
// @access   Private / Admin only route

router.get(
  "/api/v1/teamManagement/",
  authMw.ensureAuthenticated,
  teamManagementController.team_get
);

module.exports = router;
