const express = require("express");
const router = express.Router();
const teamController = require("../controllers/teamController");
const authMw = require("../config/apiauth");

// User Routes
router.post(
  "/api/v1/team",
  authMw.ensureAuthenticated,
  teamController.team_post
);

router.get("/api/v1/team", authMw.ensureAuthenticated, teamController.team_get);

router.patch(
  "/api/v1/team/:id",
  authMw.ensureAuthenticated,
  teamController.team_put
);

router.delete(
  "/api/v1/team/:id",
  authMw.ensureAuthenticated,
  teamController.team_delete
);

module.exports = router;
