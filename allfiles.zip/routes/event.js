const express = require('express');
const router = express.Router();
const eventController = require('../controllers/eventController');
const authMw = require('../config/apiauth');

// User Routes
router.post(
  "/api/v1/event",
  authMw.ensureAuthenticated,
  eventController.event_post
);

router.get(
  '/api/v1/event/:campaignID',
  authMw.ensureAuthenticated,
  eventController.event_get_for_particular_campaign
);

router.get(
  '/api/v1/event/get/:eventID',
  authMw.ensureAuthenticated,
  eventController.event_get
);

router.patch(
  "/api/v1/event/:eventID", 
  authMw.ensureAuthenticated,
  eventController.event_patch
);

router.delete(
  "/api/v1/event/:eventID",
  authMw.ensureAuthenticated,
  eventController.event_delete
);

module.exports = router;
