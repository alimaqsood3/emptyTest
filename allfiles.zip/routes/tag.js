const express = require("express");
const router = express.Router();
const tagController = require("../controllers/tagsController");
const authMw = require("../config/apiauth");

// User Routes
router.post("/api/v1/tag", authMw.ensureAuthenticated, tagController.tag_post);
router.get("/api/v1/tags", authMw.ensureAuthenticated, tagController.tag_get);
router.patch(
  "/api/v1/tag/:id",
  authMw.ensureAuthenticated,
  tagController.tag_put
);
router.delete(
  "/api/v1/tag/:id",
  authMw.ensureAuthenticated,
  tagController.tag_delete
);

module.exports = router;
