const express = require("express");
const router = express.Router();
const pipelineController = require("../controllers/pipelineController");
const authMw = require("../config/apiauth");

router.post(
  "/api/v1/pipeline",
  authMw.ensureAuthenticated,
  pipelineController.pipeline_post
);
router.get(
  "/api/v1/pipeline",
  authMw.ensureAuthenticated,
  pipelineController.pipeline_get
);
router.patch(
  "/api/v1/pipeline/:id",
  authMw.ensureAuthenticated,
  pipelineController.pipeline_put
);
router.delete(
  "/api/v1/pipeline/:id",
  authMw.ensureAuthenticated,
  pipelineController.pipeline_delete
);

module.exports = router;
