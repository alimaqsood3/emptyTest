const express = require("express");
const router = express.Router();
const templateController = require("../controllers/templateController");
const authMw = require("../config/apiauth");

// User Routes
router
  .post(
    "/api/v1/template",
    authMw.ensureAuthenticated,
    templateController.template_post
  )
  .patch(
    "/api/v1/template/:id",
    authMw.ensureAuthenticated,
    templateController.template_put
  )
  .post(
    "/api/v1/template/send",
    authMw.ensureAuthenticated,
    templateController.template_test
  )
  .get(
    "/api/v1/templates",
    authMw.ensureAuthenticated,
    templateController.template_get
  )
  .delete(
    "/api/v1/template/:id",
    authMw.ensureAuthenticated,
    templateController.template_delete
  );

module.exports = router;
