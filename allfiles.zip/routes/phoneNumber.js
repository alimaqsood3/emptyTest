const express = require("express");
const router = express.Router();
const phoneNumberController = require("../controllers/phoneNumberController");
const authMw = require("../config/apiauth");

// User Routes
router.post(
  "/api/v1/phone-number",
  authMw.ensureAuthenticated,
  phoneNumberController.phoneNumber_post
);

router.get(
  "/api/v1/phone-number",
  authMw.ensureAuthenticated,
  phoneNumberController.phoneNumber_get
);

router.post(
  "/api/v1/phone-numbers/available",
  authMw.ensureAuthenticated,
  phoneNumberController.twillio_number_get
);

router.patch(
  "/api/v1/phone-number/:id",
  authMw.ensureAuthenticated,
  phoneNumberController.phoneNumber_put
);

router.delete(
  "/api/v1/phone-number/:id",
  authMw.ensureAuthenticated,
  phoneNumberController.phoneNumber_delete
);

module.exports = router;
