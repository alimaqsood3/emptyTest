const express = require("express");
const router = express.Router();
const campaignController = require("../controllers/campaignController");
const authMw = require("../config/apiauth");

// User Routes
router.post(
  "/api/v1/campaign",
  authMw.ensureAuthenticated,
  campaignController.campaign_post
);
router.get(
  "/api/v1/campaign",
  authMw.ensureAuthenticated,
  campaignController.campaign_get
);

router.patch(
  "/api/v1/campaign/:id",
  authMw.ensureAuthenticated,
  campaignController.campaign_patch
);

router.delete(
  "/api/v1/campaign/:id",
  authMw.ensureAuthenticated,
  campaignController.campaign_delete
);

module.exports = router;
