const express = require('express');
const router = express.Router();
const upload = require('multer')();
const webhookController = require('../controllers/webhookcontroller');
const authMw = require('../config/apiauth');

router.post('/api/v1/email/incoming', upload.any(), webhookController.incoming);
router.post('/api/v1/email/outgoing', upload.any(),  webhookController.outgoing);


module.exports = router;