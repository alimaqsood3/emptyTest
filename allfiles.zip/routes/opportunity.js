const express = require("express");
const router = express.Router();
const opportunityController = require("../controllers/opportunityController");
const authMw = require("../config/apiauth");

// User Routes
router.post(
  "/api/v1/opportunity",
  authMw.ensureAuthenticated,
  opportunityController.opportunity_post
);

router.get(
  "/api/v1/opportunities",
  authMw.ensureAuthenticated,
  opportunityController.opportunity_get
);

router.patch(
  "/api/v1/opportunity/:id",
  authMw.ensureAuthenticated,
  opportunityController.opportunity_put
);

router.delete(
  "/api/v1/opportunity/:id",
  authMw.ensureAuthenticated,
  opportunityController.opportunity_delete
);

module.exports = router;
