const express = require("express");
const router = express.Router();
const companyController = require("../controllers/companyController");
const authMw = require("../config/apiauth");
const { memoryStorage } = require('multer')
const multer = require('multer')
const storage = memoryStorage();
const upload = multer({ storage })

// User Routes
router.get(
  "/api/v1/company",
  authMw.ensureAuthenticated,
  companyController.company_get
);

router.patch(
  "/api/v1/details/company/:id",
  authMw.ensureAuthenticated,
  companyController.company_put
);

router.patch(
  "/api/v1/company/update/picture/:company_id",
  authMw.ensureAuthenticated,
  companyController.company_profile_picture_patch
);

router.patch(
  "/api/v1/company/update/voicemail/:company_id",
  [authMw.ensureAuthenticated, upload.single("audio")],
  companyController.company_voicemail_patch
);

router.patch(
  "/api/v1/company/address/:id",
  authMw.ensureAuthenticated,
  companyController.company_address_put
);

router.patch(
  "/api/v1/company/missed-call/:id",
  authMw.ensureAuthenticated,
  companyController.company_missedcall_put
);

router.patch(
  "/api/v1/company/general-setting/:id",
  authMw.ensureAuthenticated,
  companyController.company_generalSetting_put
);

router.patch(
  "/api/v1/company/stages/:id",
  authMw.ensureAuthenticated,
  companyController.company_stages_put
);

module.exports = router;
