const express = require("express");
const router = express.Router();
const userController = require("../controllers/userscontroller");
const authController = require("../controllers/authcontroller");
const authMw = require("../config/apiauth");

// User Routes
router.post("/", (req, res) =>
  res.status(200).json({ status: 200, data: "API Running" })
);
router.post("/api/v1/users/register", userController.register_post);
router.post("/api/v1/users/login", authController.login_post);
router.get(
  "/api/v1/users/me",
  authMw.ensureAuthenticated,
  authController.me_get
);

module.exports = router;
