const express = require("express");
const router = express.Router();
const smtpServiceController = require("../controllers/smtpServiceController");
const authMw = require("../config/apiauth");

// User Routes
router.post(
  "/api/v1/smtpService",
  authMw.ensureAuthenticated,
  smtpServiceController.smtpService_post
);
router.get(
  "/api/v1/smtpServices",
  authMw.ensureAuthenticated,
  smtpServiceController.smtpService_get
);
router.patch(
  "/api/v1/smtpService/:id",
  authMw.ensureAuthenticated,
  smtpServiceController.smtpService_put
);
router.delete(
  "/api/v1/smtpService/:id",
  authMw.ensureAuthenticated,
  smtpServiceController.smtpService_delete
);

module.exports = router;
