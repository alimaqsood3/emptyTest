const express = require('express');
const router = express.Router();
const authMw = require('../config/apiauth');
const userController = require('../controllers/userscontroller');

router.post(
  '/api/v1/invite',
  authMw.ensureAuthenticated,
  userController.addTeam
);

module.exports = router;
