const nodemailer = require('nodemailer');

const SendMail = async (form, to, template, smtp) => {
  const transporter = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    auth: {
      user: smtp.username,
      pass: smtp.password,
    },
  });

  await transporter.sendMail({
    from: form,
    to: to,
    subject: template.subject,
    html: `${template.body}`,
  });
};

module.exports = SendMail;
