const bcrypt = require('bcryptjs')
const Company = require("../models/Company");

module.exports.getEmployerId = (user) => {
  if (user.type == "employer") {
    return user._id.toString();
  }
  if (user.type == "employee" && user.adminAccess) {
    return user.link.toString();
  }
};


// function to generate password hash using bcryptjs and using gensalt 10.
module.exports.generatePasswordHash = async(password) => {
  const salt = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash(password, salt);
  return passwordHash;
}
module.exports.getCompanyId = async (user) => {
  let userId = "";
  if (user.type == "employer") {
    userId = user._id.toString();
  }
  if (user.type == "employee" && user.adminAccess) {
    userId = user.link.toString();
  }
  let comp = await Company.findOne({ user: userId });
  return comp._id;
};
