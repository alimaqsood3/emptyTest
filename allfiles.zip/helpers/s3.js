const dotenv = require("dotenv")
// dotenv config
dotenv.config();

const AWS = require("aws-sdk")
const fs = require("fs")

const AWS_BUCKET_NAME = process.env.AWS_BUCKET_NAME
const AWS_BUCKET_REIGON = process.env.AWS_BUCKET_REIGON
const AWS_ACCESS_KEY = process.env.AWS_ACCESS_KEY
const AWS_SECRET_KEY = process.env.AWS_SECRET_KEY

const s3 = new AWS.S3({
    AWS_BUCKET_REIGON,
    AWS_ACCESS_KEY,
    AWS_SECRET_KEY
})

// uploads a file to s3
module.exports.uploadFileToS3 = async function (file) {
    const fileStream = fs.createReadStream(file.path)
    const uploadParams = {
        Bucket: AWS_BUCKET_NAME,
        Body: fileStream,
        Key: file.filename
    }
    return s3.upload(uploadParams).promise()
}

// uploads a file to s3
module.exports.uploadFileToS3ByImagePath = async function (path, name) {
    const fileStream = fs.createReadStream(path)
    const uploadParams = {
        Bucket: AWS_BUCKET_NAME,
        Body: fileStream,
        Key: name,
        ContentType: "image",
        ACL: "public-read"

    }
    return s3.upload(uploadParams).promise()
}

// uploads a file to s3
module.exports.uploadAudioToS3 = async function (name,file) {
    const uploadParams = {
        Bucket: AWS_BUCKET_NAME,
        Body: file,
        Key: name,
        ContentType: ";audio/mpeg",
        ACL: "public-read"
    }
    return s3.upload(uploadParams).promise()
}


