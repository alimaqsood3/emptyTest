const AWS = require("aws-sdk");
const fs = require("fs");
const path = require("path");
const AWS_BUCKET_NAME = "salescake";

const getFilePath = (fileName) =>
  path.resolve(__dirname, `../public/${fileName}`);

const uploadFile = async (fileName, filePath) =>
  new Promise((resolve, reject) => {
    AWS.config.update({
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION,
    });
    const s3 = new AWS.S3();
    const stream = fs.createReadStream(filePath);
    const name = `${Date.now().toString()}${fileName}`;
    //with out configuring the bucket, the file will be uploaded to the default bucket

    const obj = {
      Key: name,
      ACL: "public-read",
      Body: stream,
      ContentType: "text/csv",
      Bucket: "salescake",
    };

    s3.upload(obj, (err, data) => {
      if (err) {
        reject(err);
      } else {
        console.log(data);

        fs.unlink(getFilePath(fileName), (err) => {
          if (err) {
            console.error(err);
            return;
          }
          //file removed
        });
        resolve(data);
      }
    });
  });

module.exports = uploadFile;
