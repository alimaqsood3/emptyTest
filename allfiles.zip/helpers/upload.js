const multer = require("multer")
var storage = multer.diskStorage({
    destination: (req, file, callback) => {
        let uploadDirectory = './uploads';
        callback(null, uploadDirectory);
    },
    filename: (req, file, callback) => {
        const matchForAudio = ["audio/mp3", "audio/wav"];
        if ((file.fieldname === 'audio' && matchForAudio.indexOf(file.mimetype) === -1)) {
            var message = `${file.originalname} is invalid. Only accept mp3/wav.`;
            return callback(message, null);
        }
        var filename = `${Date.now()}-SaleCake-${file.originalname}`;
        callback(null, filename);
    }
});
var uploadFiles = multer({ storage: storage });

// limits: { fileSize: maxSize }

module.exports = uploadFiles;